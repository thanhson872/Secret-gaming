###############################
RollerCoaster Tycoon 1 
Full Version Portable
RTC1 v1.08.187 (last version)
###############################
###############################
-->> English Version:
run "PLAY English.exe"

-->> Spanish Version:
ejecuta "JUGAR Spanish.exe"
###############################
FULL: Es la version completa,
no se le ha quitado nada.
###############################
Solenbum
http://rapidshare.com/users/OC30UW



###############################
###############################

SYSTEM REQUIREMENTS
-------------------

-------> Minimum System Requirements:

Pentium 90 CPU
Windows 95/98
16 MB RAM
4X CD ROM DRIVE
at least 50MB free hard drive space
1 MB SVGA card
Windows 95 compatible Sound Card
DirectX 5.0 (included on CD)
Mouse


-------> Recommended System Requirements: (for good game performance)

Pentium 200 MMX CPU
Windows 95/98
32 MB RAM
8X CD ROM DRIVE
at least 50MB free hard drive space
2 MB accelerated SVGA card
Windows 95 compatible Sound Card
DirectX 5.0 (included on CD)
Mouse


-------> Ideal System Requirements: (for ultimate game performance)

Pentium II 350 CPU
Windows 95/98
64 MB RAM
8X CD ROM DRIVE
at least 180 MB free hard drive space
4 MB accelerated SVGA card
Windows 95 compatible Sound Card
DirectX 5.0 (included on CD)
Mouse